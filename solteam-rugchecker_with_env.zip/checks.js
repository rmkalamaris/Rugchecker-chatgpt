const { Connection, PublicKey } = require("@solana/web3.js");
const axios = require("axios");
const Decimal = require("decimal.js");
const { parseProgramLogs } = require("./logs");
const { simulateSwapRoute } = require("./dex");
const { loadHolderStats, getPoolInfoForToken } = require("./onchainHelpers");

const connection = new Connection(process.env.RPC_URL || "https://api.mainnet-beta.solana.com", "confirmed");
const HELIUS_KEY = process.env.HELIUS_API_KEY || null;

async function doCoreChecks(mintAddress) {
  const res = {};
  const mintPub = new PublicKey(mintAddress);

  // 1) Mint account info (mintAuthority, freezeAuthority, supply)
  const mintAcc = await connection.getParsedAccountInfo(mintPub);
  if (!mintAcc.value) throw new Error("Mint account not found or invalid address");
  const parsed = mintAcc.value.data?.parsed;
  if (!parsed || parsed.type !== "mint") throw new Error("Address is not an SPL mint account");
  const info = parsed.info || {};
  res.mintAuthority = info.mintAuthority || null;
  res.freezeAuthority = info.freezeAuthority || null;
  res.supply = info.supply || null;

  // 2) Recent authority changes and recent mints via Helius or getSignaturesForAddress
  res.recentMintEvents = await _getRecentMintEvents(mintPub);

  // 3) Top holders concentration
  const holders = await connection.getTokenLargestAccounts(mintPub); // returns token account pubkeys + amount
  const top = holders.value || [];
  // Map token accounts to owners and totals
  res.topHolders = await loadHolderStats(connection, top);
  res.topHoldersPercent = computeTopHolderPercent(res.topHolders);

  return res;
}

async function doExhaustiveChecks(mintAddress) {
  const res = {};
  const mintPub = new PublicKey(mintAddress);

  // Liquidity: try to find pools on common AMMs
  res.pools = await getPoolInfoForToken(connection, mintPub); // returns list of pools with owners, token vaults, share distribution
  // Analyze liquidity concentration
  res.liquidityRisk = analyzePools(res.pools);

  // Program log analysis (calls like setAuthority, withdraw, setFee)
  res.programLogs = await parseProgramLogs(mintPub, { heliusKey: HELIUS_KEY, connection });

  // Honeypot simulation (simulate route via dex aggregator)
  try {
    res.honeypotCheck = await honeypotSimulation(mintAddress);
  } catch (e) {
    res.honeypotCheck = { error: e.message };
  }

  // Check program upgrade authority if token uses custom program (advanced)
  res.programUpgradeInfo = await checkProgramUpgradeInfoIfAny(mintPub);

  return res;
}

/* helper implementations */

async function _getRecentMintEvents(mintPub) {
  // Use Helius if available for event logs; fallback to getSignaturesForAddress and parse
  try {
    if (HELIUS_KEY) {
      const url = `https://api.helius.xyz/v0/addresses/${mintPub.toBase58()}/transactions?api-key=${HELIUS_KEY}&type=parsed`;
      const r = await axios.get(url, { timeout: 10000 });
      const txs = r.data || [];
      // scan for MintTo instructions
      const mints = [];
      for (const tx of txs) {
        if (tx?.signature && tx?.parsedTransactions) {
          // heuristic: search instructions
          const logs = JSON.stringify(tx);
          if (logs.match(/MintTo|mintTo|mint_to/i)) {
            mints.push({ signature: tx.signature, raw: tx });
          }
        }
      }
      return { source: "helius", mints: mints.slice(0, 25) };
    } else {
      // fallback
      const sigs = await connection.getSignaturesForAddress(mintPub, { limit: 50 });
      const results = [];
      for (const s of sigs) {
        const tx = await connection.getParsedTransaction(s.signature);
        if (!tx) continue;
        const msg = JSON.stringify(tx);
        if (msg.match(/MintTo|mintTo|mint_to/i)) {
          results.push({ signature: s.signature, slot: s.slot });
        }
      }
      return { source: "rpc", mints: results };
    }
  } catch (e) {
    return { error: e.message };
  }
}

function computeTopHolderPercent(topHolders) {
  // topHolders: [{owner, amountRaw, decimals}] amounts are raw token amounts as strings
  try {
    const totals = topHolders.map(h => new Decimal(h.amountRaw));
    const supply = totals.reduce((acc, v) => acc.plus(v), new Decimal(0));
    const top1 = totals[0] || new Decimal(0);
    if (supply.eq(0)) return 0;
    return top1.div(supply).mul(100).toNumber();
  } catch (e) {
    return null;
  }
}

async function honeypotSimulation(mintAddress) {
  // By default simulate route price (no real trade). If user enables microtrade & keys present then can actually do microtrade.
  // Use a DEX aggregator API to get route (e.g., Jupiter API) — here we simulate via public Jupiter quote endpoints.
  try {
    const sim = await simulateSwapRoute(mintAddress);
    return sim;
  } catch (e) {
    return { error: e.message };
  }
}

async function checkProgramUpgradeInfoIfAny(mintPub) {
  // Token mints normally use SPL Token program; custom program usage needs extra parsing.
  // Placeholder: returns empty unless custom program inspected
  return {};
}

function analyzePools(pools) {
  // Simple heuristics: pool count, largest LP contributor, locked status
  try {
    const summary = { poolCount: pools.length, risks: [] };
    for (const p of pools) {
      if (!p.locked && p.liquidityOwnerSingle && p.liquidityOwnerSingle.percent > 60) {
        summary.risks.push(`Pool ${p.id} has >60% liquidity from single wallet ${p.liquidityOwnerSingle.owner}`);
      }
      if (!p.locked && p.ownerIsDev) {
        summary.risks.push(`Pool ${p.id} authority is a dev wallet and not locked`);
      }
    }
    return summary;
  } catch (e) {
    return { error: e.message };
  }
}

module.exports = { doCoreChecks, doExhaustiveChecks };
