const { Telegraf } = require("telegraf");
const botToken = process.env.TELEGRAM_TOKEN;
const bot = new Telegraf(botToken);

async function sendAdminAlert(text) {
  const admin = process.env.ADMIN_CHAT_ID;
  if (!admin) return console.warn("No ADMIN_CHAT_ID set, skipping admin alert");
  try {
    await bot.telegram.sendMessage(admin, text, { parse_mode: "Markdown" });
  } catch (e) {
    console.error("Admin alert failed:", e.message);
  }
}

module.exports = { sendAdminAlert };
