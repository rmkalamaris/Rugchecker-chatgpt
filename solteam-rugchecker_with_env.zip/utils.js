const { Connection } = require("@solana/web3.js");
async function testRpc() {
  try {
    const conn = new Connection(process.env.RPC_URL || "https://api.mainnet-beta.solana.com", "confirmed");
    const v = await conn.getEpochInfo();
    return { ok: true, epoch: v.epoch };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

module.exports = { testRpc };
