function computeScore(data) {
  let score = 0;
  // Critical checks
  if (data.mintAuthority) score += 50;
  if (data.freezeAuthority) score += 30;
  if (data.recentMintEvents && data.recentMintEvents.mints && data.recentMintEvents.mints.length > 0) score += 30;
  if (data.topHoldersPercent && data.topHoldersPercent > 40) score += 20;
  // liquidity heuristics
  if (data.liquidityRisk && data.liquidityRisk.risks && data.liquidityRisk.risks.length > 0) score += 25;
  // logs
  if (data.programLogs && data.programLogs.suspicious && data.programLogs.suspicious.length > 0) score += 30;
  // honeypot simulation
  if (data.honeypotCheck && data.honeypotCheck.error) score += 40;
  if (data.honeypotCheck && data.honeypotCheck.simulated === true && data.honeypotCheck.quotesSummary && data.honeypotCheck.quotesSummary.length === 0) score += 10;

  // clamp
  if (score > 100) score = 100;
  return score;
}

function formatSummary(mint, data, score) {
  let md = `*SOLTEAM Rugpull Quick Scan*\n\nToken: \`${mint}\`\nScore: *${score}/100*\n\n`;
  md += `• Mint Authority: ${data.mintAuthority ? `⚠️ ${data.mintAuthority}` : "✅ Revoked"}\n`;
  md += `• Freeze Authority: ${data.freezeAuthority ? `⚠️ ${data.freezeAuthority}` : "✅ Revoked"}\n`;
  md += `• Top1 Holder %: ${data.topHoldersPercent ? data.topHoldersPercent.toFixed(2) + "%" : "N/A"}\n`;
  if (data.recentMintEvents && data.recentMintEvents.mints && data.recentMintEvents.mints.length) {
    md += `• Recent mint events detected: ${data.recentMintEvents.mints.length}\n`;
  }
  return { summaryMarkdown: md };
}

function formatFullReport(mint, data, score) {
  const s = formatSummary(mint, data, score).summaryMarkdown;
  let md = s + `\n*Exhaustive Report:*\n`;
  md += `• Pools found: ${(data.pools && data.pools.length) || 0}\n`;
  if (data.liquidityRisk && data.liquidityRisk.risks && data.liquidityRisk.risks.length) {
    md += `• Liquidity risks: \n`;
    for (const r of data.liquidityRisk.risks) md += `  - ${r}\n`;
  }
  if (data.programLogs && data.programLogs.suspicious && data.programLogs.suspicious.length) {
    md += `• Suspicious program logs found: ${data.programLogs.suspicious.length}\n`;
  }
  if (data.honeypotCheck) {
    md += `• Honeypot simulation: ${data.honeypotCheck.error ? "ERROR: " + data.honeypotCheck.error : JSON.stringify(data.honeypotCheck.quotesSummary ? "Route found" : "No route")}\n`;
  }
  return { fullReportMarkdown: md, summaryMarkdown: s };
}

module.exports = { computeScore, formatSummary, formatFullReport };
