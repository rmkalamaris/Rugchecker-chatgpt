const axios = require("axios");

async function simulateSwapRoute(mintAddress) {
  try {
    const jupQuoteUrl = `https://quote-api.jup.ag/v1/quote?inputMint=So11111111111111111111111111111111111111112&outputMint=${mintAddress}&amount=1000000`;
    const r = await axios.get(jupQuoteUrl, { timeout: 8000 });
    const quotes = r.data;
    if (!quotes || quotes.length === 0) return { simulated: false, reason: "No route found" };
    return { simulated: true, quotesSummary: quotes.slice(0, 3) };
  } catch (e) {
    return { error: e.message };
  }
}

module.exports = { simulateSwapRoute };
