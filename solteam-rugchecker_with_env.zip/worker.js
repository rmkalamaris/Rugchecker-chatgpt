const { Queue, Worker } = require("bullmq");
const IORedis = require("ioredis");
const { runChecksCommand } = require("./commands");

let connection = null;
if (process.env.REDIS_URL) {
  connection = new IORedis(process.env.REDIS_URL);
} else {
  connection = new IORedis(); // default localhost
}

const queueName = "rugchecks";
const myQueue = new Queue(queueName, { connection });

function createWorkerQueue() {
  // Start worker
  const worker = new Worker(queueName, async (job) => {
    const { mint, exhaustive } = job.data;
    const r = await runChecksCommand(mint, { exhaustive });
    return r;
  }, { connection });

  worker.on("completed", (job, result) => {
    console.log("Job completed:", job.id, result.score);
  });
  worker.on("failed", (job, err) => {
    console.error("Job failed:", job.id, err.message);
  });

  console.log("Worker queue created");
}

module.exports = { createWorkerQueue, myQueue };
