# SOLTEAM Rugpull Checker Bot

This is a Telegram bot to analyze Solana tokens for rugpull risk.

## Setup

1. Clone repo or unzip files
2. Create `.env` file with your credentials
3. Run:
   ```bash
   npm install
   npm start
   ```

## Commands

- /start → Welcome message  
- /scan <token_address> → Scan token  
- /top10 → Show safest & riskiest tokens  
- /buy → Redirect to snipe bot  
- /trending → Trending tokens  
- /help → Show help  
