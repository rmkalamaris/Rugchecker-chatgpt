require('dotenv').config();
const { Telegraf } = require('telegraf');
const axios = require('axios');

const bot = new Telegraf(process.env.TELEGRAM_TOKEN);

// /start
bot.start((ctx) => {
  ctx.reply('🤖 Welcome to SOLTEAM Rugpull Checker! Use /scan <token_address> to analyze a token.');
});

// /scan
bot.command('scan', async (ctx) => {
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply('❌ Please provide a token address: /scan <token_address>');
  const tokenAddress = args[1];

  try {
    const response = await axios.post(process.env.RPC_URL, {
      jsonrpc: "2.0",
      id: 1,
      method: "getTokenSupply",
      params: [tokenAddress]
    });
    ctx.reply(`✅ Scanned token ${tokenAddress}\nSupply: ${JSON.stringify(response.data)}`);
  } catch (err) {
    ctx.reply(`❌ Error scanning token: ${err.message}`);
  }
});

// /top10
bot.command('top10', (ctx) => {
  ctx.reply('📊 Top 10 Safest & Most Unsafe tokens feature is under development.');
});

// /buy
bot.command('buy', (ctx) => {
  ctx.reply('💸 Soon you will be able to buy directly via SOLTEAM Snipe Bot.');
});

// /trending
bot.command('trending', (ctx) => {
  ctx.reply('🔥 Trending tokens will be shown here with their risk levels.');
});

// /help
bot.help((ctx) => {
  ctx.reply('📌 Commands:\n/start - Welcome message\n/scan <token> - Scan a token\n/top10 - Show safest/riskiest tokens\n/buy - Redirect to Snipe Bot\n/trending - Show trending tokens');
});

bot.launch();
